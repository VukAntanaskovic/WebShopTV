function sendMail(){
    var name = document.getElementsByName("Name")[0].value;
    var address = document.getElementsByName("Address")[0].value;
    var item = document.getElementById("Item").value;
    var note = document.getElementsByName("Note")[0].value;
    var body = "Full name: " + name + ",%0D%0AAddress: " +address + ",%0D%0AItem: " + item + ",%0D%0ANote: " + note;

    if(name && address && item){
    window.open("mailto:someone@example.com?subject="+name+"&body="+ body);
    }
    else{
        alert("Please fill all fields");
    }
}

function sendWa(){
    var name = document.getElementsByName("Name")[0].value;
    var address = document.getElementsByName("Address")[0].value;
    var item = document.getElementById("Item").value;
    var note = document.getElementsByName("Note")[0].value;
    var body = "Hello my name is " + name + ", my address is " +address + ", and I want to order item " + item + ", with note: " + note;
    
    if(name && address && item){
    window.open("https://api.whatsapp.com/send?phone=1111111111&text=" + body);
    }
    else{
        alert("Please fill all fields");
    }
}

function execAction(){
    var itemId = document.getElementsByName("itemId")[0].value;

    var name = document.getElementsByName("itemName")[0].value;
    var code = document.getElementsByName("itemCode")[0].value;
    var price = document.getElementsByName("itemPrice")[0].value;
    var image = document.getElementsByName("itemImage")[0].value;

    if(name && code && price){
        if(itemId){
        }
    }
    else{
        alert("Please fill all the fields");
    }
}