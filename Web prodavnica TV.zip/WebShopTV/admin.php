<?php 
include("views/fixed/header.php");
include("views/fixed/navbar.php");
include("config/connection.php");

        $sifra = $_SESSION["id_korisnika"];
        $upit = "SELECT * FROM administrator WHERE id_korisnika = '$sifra'";
        $rezultat = $db->query($upit);
        if($rezultat->num_rows > 0){
            echo '<h1 align="center">Admin panel</h2>';
        }
        else{
            header("Location: index.php");
        }
//Dodatna validacija korisnika, ukoliko pokusa preko url da udje na admin panel
?>
<div class="container-fluid">
<div class="row" id="admin-row">
<div class="col-md-6">
<form method="POST" class="forma-admin" action="models/admin/insertBrend.php">
<label for="brend">Dodavanje i brisanje brenda:</label>
<input class="form-control" type="text" name="brend" id="kontrola-admin" placeholder="Unesite naziv brenda..." required> 
<input type="submit" value="Unesite brend" name="btnUnesiteBrend" class="btn btn-primary">
<input type="submit" value="Obrisite brend" name="btnObrisiteBrend" class="btn btn-danger">
<?php 
if(isset($_SESSION["poruka"])){
    echo $_SESSION["poruka"];
}
?>
</form>
</div>
<div class="col-md-6">
<form method="POST" class="forma-admin" action="models/admin/insertAdmin.php">
<label for="radnik">Dodavanje i brisanje admina:</label>
<select class="form-select" aria-label="Default select example" type="text" name="sifra_korisnika" id="kontrola-admin">
    <?php 
    $upit = "SELECT * FROM korisnik";
    $rezultat = $db->query($upit);
    while($row=$rezultat->fetch_array()){
        echo '<option value="'.$row["id_korisnika"].'">'.$row["ime"].' '.$row["prezime"].'</option>';
    }
    //uzimanje svih korisnika iz baze
    ?>
</select>
<input type="submit" value="Unesite admina" name="btnUnesiteAdmina" class="btn btn-primary">
<input type="submit" value="Obrisite admina" name="btnObrisiteAdmina" class="btn btn-danger">
<?php 
if(isset($_SESSION["porukaAdmin"])){
    echo $_SESSION["porukaAdmin"];
}
?>
</form>

</div>
</div>
<br><br>
<div class="row">
<div class="col-md-12">
<form method="POST" class="forma-admin" action="models/admin/insertArtikal.php" enctype="multipart/form-data">
<h3>Dodavanje novog artikla</h3>
<div class="row">
    <div class="col-md-3">
        <label for="kontrola-admin">Marka:</label>
        <select class="form-select" aria-label="Default select example" type="text" name="marka" id="kontrola-admin">
    <?php 
    $upit = "SELECT * FROM brend";
    $rezultat = $db->query($upit);
    while($row=$rezultat->fetch_array()){
        echo '<option value="'.$row["Id"].'">'.$row["Naziv"].'</option>';
    }
    //uzimanje svih brendova iz baze
    ?>
</select>
    </div>
    <div class="col-md-3">
        <label for="kontrola-admin">Model:</label>
        <input class="form-control" type="text" name="model" id="kontrola-admin" placeholder="Unesite model artikla..." required> 
    </div>
    <div class="col-md-3">
        <label for="kontrola-admin">Cena:</label>
        <input class="form-control" type="text" name="cena" id="kontrola-admin" placeholder="Unesite cenu artikla..." required> 
    </div>
    <div class="col-md-3">
        <label for="kontrola-admin">Dijagonala:</label>
        <input class="form-control" type="text" name="dijagonala" id="kontrola-admin" placeholder="Unesite dijagonalu artikla..." required> 
    </div>
</div>


<div class="row">
<div class="col-md-3">
        <label for="kontrola-admin">Rezolucija:</label>
        <input class="form-control" type="text" name="rezolucija" id="kontrola-admin" placeholder="Unesite rezoluciju artikla..." required> 
    </div>
    <div class="col-md-3">
        <label for="kontrola-admin">Smart:</label>
        <select class="form-select" aria-label="Default select example" type="text" name="smart" id="kontrola-admin">
        <option value="da">da</option>
        <option value="ne">ne</option>
</select>
</div>
    <div class="col-md-3">
        <label for="kontrola-admin">Tjuner:</label>
        <input class="form-control" type="text" name="tjuner" id="kontrola-admin" placeholder="Unesite tjuner artikla..." required> 
    </div>
    <div class="col-md-3">
        <label for="kontrola-admin">HDMI:</label>
        <input class="form-control" type="text" name="hdmi" id="kontrola-admin" placeholder="Unesite broj hdmi portova..." required> 
    </div>
</div>
<div class="row">
<div class="col-md-6">
<label for="kontrola-admin">USB:</label>
<input class="form-control" type="text" name="usb" id="kontrola-admin" placeholder="Unesite broj usb portova..." required> 
</div>
<div class="col-md-6">
<div class="mb-3">
  <label for="formFile" class="form-label">Izaberite naslovnu sliku:</label>
  <input class="form-control" type="file" id="formFile" name="NaslovnaImg" required>
</div></div>
</div>
<div class="row">
<div class="col-md-4">
<div class="mb-3">
  <label for="formFile" class="form-label">Izaberite sliku:</label>
  <input class="form-control" type="file" id="formFile" name="img1" required>
</div>
</div>
<div class="col-md-4">
<div class="mb-3">
  <label for="formFile" class="form-label">Izaberite sliku:</label>
  <input class="form-control" type="file" id="formFile" name="img2" required>
</div>
</div>
<div class="col-md-4">
<div class="mb-3">
  <label for="formFile" class="form-label">Izaberite sliku:</label>
  <input class="form-control" type="file" id="formFile" name="img3" required>
</div>
</div>
</div>
<input type="submit" value="Unesite novi artikal" name="btnUnesiteArtikal" class="btn btn-primary">
<?php 
if(isset($_SESSION["porukaArtikal"])){
    echo $_SESSION["porukaArtikal"];
}
?>
</form>
    </div>
</div>
<div class="row" id="admin-row">
<div class="col-md-6">
<form method="POST" class="forma-admin" action="models/admin/insertIzdvajamo.php">
<label for="kontrola-admin">Dodavanje i brisanje artikla iz izdvajamo iz ponude:</label>
<select class="form-select" aria-label="Default select example" type="text" name="sifra_artikla" id="kontrola-admin">
    <?php 
    $upit = "SELECT * FROM artikal";
    $rezultat = $db->query($upit);
    while($row=$rezultat->fetch_array()){
        echo '<option value="'.$row["sifra_artikla"].'">'.$row["sifra_artikla"].' - '.$row["model"].'</option>';
    }
    //uzimanje svih artikala iz baze
    ?>
</select>
<input type="submit" value="Unesite artikal" name="btnUnesiteIzdvajamo" class="btn btn-primary">
<input type="submit" value="Obrisite artikal" name="btnObrisiteIzdvajamo" class="btn btn-danger">
<?php 
if(isset($_SESSION["porukaIzdvajamo"])){
    echo $_SESSION["porukaIzdvajamo"];
}
?>
</form>
</div>
<div class="col-md-6">
<form method="POST" class="forma-admin" action="models/admin/insertOdabrano.php">
<label for="kontrola-admin">Dodavanje i brisanje artikla iz odbrano za vas:</label>
<select class="form-select" aria-label="Default select example" type="text" name="sifra_artikla" id="kontrola-admin">
    <?php 
    $upit = "SELECT * FROM artikal";
    $rezultat = $db->query($upit);
    while($row=$rezultat->fetch_array()){
        echo '<option value="'.$row["sifra_artikla"].'">'.$row["sifra_artikla"].' - '.$row["model"].'</option>';
    }
    //uzimanje svih artikala iz baze
    ?>
</select>
<input type="submit" value="Unesite artikal" name="btnUnesiteOdabrano" class="btn btn-primary">
<input type="submit" value="Obrisite artikal" name="btnObrisiteOdabrano" class="btn btn-danger">
<?php 
if(isset($_SESSION["porukaOdabrano"])){
    echo $_SESSION["porukaOdabrano"];
}
?>
</form>

</div>
</div>
<div class="row" id="admin-row">
<div class="col-md-12">
<form method="POST" class="forma-admin" action="models/admin/promenaCene.php">
<h3>Promena cene</h3>
<div class="row">
<div class="col-md-6">
<label for="kontrola-admin">Izaberite artikal:</label>
<select class="form-select" aria-label="Default select example" type="text" name="sifra_artikla" id="kontrola-admin">
    <?php 
    $upit = "SELECT * FROM artikal";
    $rezultat = $db->query($upit);
    while($row=$rezultat->fetch_array()){
        echo '<option value="'.$row["sifra_artikla"].'">'.$row["sifra_artikla"].' - '.$row["model"].'</option>';
    }
    //uzimanje svih artikala iz baze
    ?>
</select>
</div>
<div class="col-md-6">
<label for="kontrola-admin">Unesite novu cenu:</label>
<input type="text" name="promenaCene" id="kontrola-admin" class="form-control" placeholder="Unesite novu cenu">
</div>
</div>
<input type="submit" value="Promenite cenu" name="btnUnesiteIzdvajamo" class="btn btn-success">
<?php 
if(isset($_SESSION["porukaCena"])){
    echo $_SESSION["porukaCena"];
}
?>
</form>
</div>
</div>
<div class="row" id="admin-row">
<div class="col-md-6" id="tabela-korisnika">
<table class="table table-striped">
    <h3>Pregled registrovanih korisnika</h3>
  <thead>
    <tr>
      <th scope="col">Ime</th>
      <th scope="col">Prezime</th>
      <th scope="col">Email</th>
    </tr>
  </thead>
  <tbody>
    <?php 
    $upit = "SELECT * FROM korisnik";
    $rezultat = $db->query($upit);
    while($row=$rezultat->fetch_array()){
        echo '<tr><td>'.$row["ime"].'</td><td>'.$row["prezime"].'</td><td>'.$row["email"].'</td></tr>';
    }
    //uzimanje svih korisnika iz baze
    ?>
  </tbody>
</table>
</div>
</div>

<div class="row" id="admin-row">
<div class="col-md-6" id="tabela-korisnika">
<h3>Pregled komentara korisnika</h3>
<?php 
$upit = "SELECT * FROM forma";
$rezultat = $db->query($upit);
while($row=$rezultat->fetch_array()){
    echo '<div class="komentar-pregled"><h4>'.$row["ime"].' - '.$row["email"].'</h4><p style="margin:0; padding:0;">'.$row["poruka"].'</p></div><br>';
}
//uzimanje svih komentara iz baze
?>
</div>
</div>
<br><br>
<div class="row"></div>
<div class="col-md-6" id="tabela-narudzbenica" style="margin-bottom:5%;">
<h3>Pregled narudzbenica</h3>
<?php 
$upit = "SELECT * FROM narudzbenica";
$rezultat = $db->query($upit);
while($row=$rezultat->fetch_array()){
    $sifraKorpe = $row["sifra_korpe"];
    $upitPrikaz = "SELECT * FROM stavke_korpe AS s INNER JOIN artikal AS a ON s.sifra_artikla = a.sifra_artikla WHERE sifra_korpe='$sifraKorpe'";
    $rezultatPrikaz = $db->query($upitPrikaz);
    $ukupno = 0;
    echo '<div class="komentar-pregled" id="narudzbenica"><h4>'.$row["broj"].' - '.$row["ime"].' '.$row["prezime"].' | '.$row["adresa"].' | '.$row["broj_telefona"].'</h4><p style="margin:0; padding:0;"></p></div>
    <br> <div class="row" id="stampa"><div class="col-md-12"><table  style="margin-bottom:2%;" class="table table-striped">
    <thead>
      <tr>
        <th scope="col">Naziv artikla</th>
        <th scope="col">Kolicina</th>
        <th scope="col">Cena</th>
      </tr>
    </thead>
    <tbody>';
        while($rowPrikaz=$rezultatPrikaz->fetch_array()){
          $cena = $rowPrikaz["cena"]*$rowPrikaz["kolicina"];
          $ukupno+=$cena;
            echo '<tr><td>'.$rowPrikaz["model"].'</td><td>'.$rowPrikaz["kolicina"].'<td>'.$cena.'</td></tr>';
        }
        echo '</tbody>
        </table>';
    }

    //uzimanje svih narudzbenica iz baze
?>
</div>
</div>
</div>
<script type="text/javascript">
$(window).on('load' , function(){
    $("#pocetna-link").removeClass("active");
});

</script>
<script type="text/javascript" src="assets/js/main.js"></script>
