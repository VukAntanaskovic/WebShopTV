window.onload=function(){
    dohvatiProizvode();
    dohvatiProizvodeOdabrano();
  }//pozivanje funkcija
//dohvati izdvajamo iz ponude proizvode

function dohvatiProizvode(){
    $.ajax({
      url:"models/dohvatiProizvodePonuda.php",
      method:"GET",
      dataType:"JSON",
  
      success:function(data){
        ispisiProizvode(data);
      },
      error:function(){
        console.log("error dohvati proizvode");
      }
    });
  }//dohvati proizvode izdvojeno iz ponude
  
  function ispisiProizvode(data){
    var lista = document.getElementById("proizvodi");
    var stavke ="";
  for(var d of data){
          stavke += `
          <div class="kartica">
            <div class="slika">
              <img src="${d[3]}" alt="TV">
            </div>
            <div class="naslov-kartice">
              <h3>${d[0]}</h3>
              <h4>${d[1]}</h4> 
            </div>
            <div class="cena-kartice">
              <h3>${d[2]}</h3>
            </div>
            <div class="dugme-kartice">
              <a href="models/korpa.php${d[4]}"><i class="fas fa-shopping-cart"></i> <span>Dodaj u korpu</span></a>
            </div>
            <div id="detaljnije" class="dugme-kartice">
              <a href="detalji.php${d[4]}"><i class="fas fa-search"></i> <span>Detaljnije</span></a>
            </div>
          </div>`;
        }
    lista.innerHTML = stavke;
  }//ispis proizvoda izdvojeno iz ponude
  //--dohvati izdvajamo iz ponude proizvode

  //dohvati odabrano za vas
  function dohvatiProizvodeOdabrano(){
    $.ajax({
      url:"models/dohvatiProizvodeOdabrano.php",
      method:"GET",
      dataType:"JSON",
  
      success:function(data){
        ispisiProizvodeOdabrano(data);
      },
      error:function(){
        console.log("error dohvati proizvode");
      }
    });
  }//dohvati proizvode odabrano za vas
  
  function ispisiProizvodeOdabrano(data){
    var lista = document.getElementById("proizvodi-odabrano");
    var stavke ="";
  for(var d of data){
          stavke += `
          <div class="kartica">
            <div class="slika">
              <img src="${d[3]}" alt="TV">
            </div>
            <div class="naslov-kartice">
              <h3>${d[0]}</h3>
              <h4>${d[1]}</h4> 
            </div>
            <div class="cena-kartice">
              <h3>${d[2]}</h3>
            </div>
            <div class="dugme-kartice">
              <a href="models/korpa.php${d[4]}"><i class="fas fa-shopping-cart"></i> <span>Dodaj u korpu</span></a>
            </div>
            <div id="detaljnije" class="dugme-kartice">
              <a href="detalji.php${d[4]}"><i class="fas fa-search"></i> <span>Detaljnije</span></a>
            </div>
          </div>`;
        }
    lista.innerHTML = stavke;
  }//ispis proizvoda odabrano za vas
  //--dohvati odabrano za vas
  
  