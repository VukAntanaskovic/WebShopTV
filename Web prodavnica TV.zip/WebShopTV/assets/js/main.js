$(document).ready(function(){
    dohvatiNavigaciju();
    pretragaProizvoda();
    sakritiPretragu();
  });

//punjenje kategorije prozivoda iz baze
function dohvatiNavigaciju(){
    $.ajax({
      url: "models/dohvatiNav.php",
      method: "GET",
      dataType:"json",
      
      success:function(data){
        ispisiNavigaciju(data);
      },
      error:function(){
        console.log("Error dohvati nav");
      }
    });
  }//dohvati kategorije 
  
  function ispisiNavigaciju(data){
    var lista = document.getElementById("padajuci-meni");
    var stavke ="";
  for(var d of data){
          stavke += `<li><a class='dropdown-item' href='kategorije.php${d[1]}'><i class="fas fa-tv"></i>  <b>${d[0]}</a></li>`;
        }
    lista.innerHTML = stavke;
  }//ispis kategorija 
  //--punjenje kategorije prozivoda iz baze

  //pretraga
  function pretragaProizvoda(){
    $("#txtPretraga").keyup(function(){
      var searchText = $(this).val();
      if(searchText != null){
    $.ajax({
      url:"models/pretraga.php",
      method:"POST",
      data:{query:searchText},
      dataType:"JSON",
  
      success:function(data){
        if($(this).text() != null){
          $("#pretraga").css("display" , "block");
          ispisiTrazeneProizvode(data);
        }
  
      },
      error:function(){
        console.log("error pretraga proizvoda");
      }
    });
  }
  else{
    $("#dugme-pretraga").on("click" , function(){
      $("#pretraga").css("display" , "none");
  
    })
  
  }
  });
  }//funkcija za pretragu
  
  function ispisiTrazeneProizvode(data){
    var lista = document.getElementById("pretraga");
    var stavke ="";
  for(var d of data){
          stavke += `
          <a class="link-pretrage" href="detalji.php${d[7]}"><div class="kartica-pretrage">
  <div class="slika-pretrage">
  <img src="${d[3]}">
  </div>
  <div class="detalji-pretrage">
  <h4>${d[0]}</h4>
  <p>${d[1]}</p>
  <p>${d[2]}</p>
  </div>
  <div class="detalji-pretrage">
  <h4>${d[6]}</h4>
  <p>${d[4]}</p>
  <p>${d[5]}</p>
  </div>
  </div></a>`;
  
        }
    lista.innerHTML = stavke;
  }//ispis pretrazenih proizvoda
  
  function sakritiPretragu(){
  $("body").on("click" , function(){
    $("#pretraga").css("display" , "none");
  });
}

  $("#txtPretraga").keyup(function(e){
  if (e.keyCode == 8 && !$("#txtPretraga").val()) {
    $("#pretraga").css("visibility" , "hidden");
  }
  else{
    $("#pretraga").css("visibility" , "visible");
  }
});
//sakrivanje pretrage kada je input prazan
  //--pretraga