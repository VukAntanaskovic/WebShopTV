window.onload=function(){
    dohvatiSveProizvode();
    dohvatiBrend();
  }
//dohvati sve proizvode
var filter;
var filterDijagonala;
function dohvatiSveProizvode(){
    $.ajax({
      url:"models/dohvatiSveProizvode.php",
      method:"GET",
      dataType:"JSON",
      success:function(data){
        var x = document.getElementById("combo-sort").value;
          if(x == "CenaRastuce"){
             data.reverse();
             if(filter != null){
                data = data.filter(d => d[0] == filter);
            }
            if(filterDijagonala != null){
                data = data.filter(d => d[4] == filterDijagonala);
            }
          }
          else if(x == "Marka"){
            data.sort();
            if(filter != null){
                data = data.filter(d => d[0] == filter);
            }
            if(filterDijagonala != null){
                data = data.filter(d => d[4] == filterDijagonala);
            }
          }
          else if(filter != null){
              data = data.filter(d => d[0] == filter);
              if(filterDijagonala != null){
                data = data.filter(d => d[4] == filterDijagonala);
            }
          }
          else if(filterDijagonala != null){
            data = data.filter(d => d[4] == filterDijagonala);
            if(filter != null){
                data = data.filter(d => d[0] == filter);
            }
        }
          ispisiSveProizvode(data);

        
        $("#pocetna-link").removeClass("active");
        $("#proizvodi-link").addClass("active");
      },
      error:function(){
        console.log("error dohvati proizvode");
      }
    });
  }//hvatanje svih proizvoda, sa akcentom na moguce filterovanje
  
  function ispisiSveProizvode(data){
    var lista = document.getElementById("svi-proizvodi");
    var stavke ="";
  for(var d of data){
          stavke += `
          <div class="kartica">
            <div class="slika">
              <img src="${d[3]}" alt="TV">
            </div>
            <div class="naslov-kartice">
              <h3>${d[0]}</h3>
              <h4>${d[1]}</h4> 
            </div>
            <div class="cena-kartice">
              <h3>${d[2]}</h3>
            </div>
            <div class="dugme-kartice">
              <a href="models/korpa.php${d[5]}"><i class="fas fa-shopping-cart"></i> <span>Dodaj u korpu</span></a>
            </div>
            <div id="detaljnije" class="dugme-kartice">
              <a href="detalji.php${d[5]}"><i class="fas fa-search"></i> <span>Detaljnije</span></a>
            </div>
          </div>`;
        }
    lista.innerHTML = stavke;
  }//ispis svih filtriranih proizvoda

  
  //--dohvati sve proizvode
  
  //punjenje brenda iz baze
  function dohvatiBrend(){
    $.ajax({
      url: "models/dohvatiNav.php",
      method: "GET",
      dataType:"json",
      
      success:function(data){
        ispisiBrend(data);
      },
      error:function(){
        console.log("Error dohvati nav");
      }
    });
  }//punjenje filtera iz baze
  
  function ispisiBrend(data){
    var lista = document.getElementById("lista-proizvodjaca");
    var stavke ="";
  for(var d of data){
          stavke += `<li id="link-brend" onclick="UzmiVrednost(this);dohvatiSveProizvode()" value="${d[0]}">> ${d[0]}</li>`;
        }
        stavke += `<li id="link-brend" onclick="location.reload()" value="Svi">> Svi brendovi</li>`;

    lista.innerHTML = stavke;
  }//ispis filtera
  //--punjenje brenda iz baze
  
function UzmiVrednost(obj){

        var x = obj.getAttribute("value");
        filter = x;
}//dodeljivanje filtera brenda
function UzmiVrednostDijagonale(obj){
    var x = obj.getAttribute("value");
    filterDijagonala = x;
}//dodeljivanje filtera dijagonale

