<?php 
include("views/fixed/header.php");
include("views/fixed/navbar.php");
$pretraga = $_POST["pretraga"]; //hvatanje vrednosti iz URL-a
?>

<h2 class="naslov">Trazili ste: <span class="trazena-kat"><?php echo $pretraga ?></span></h2>
<div class="iz-ponuda" id="proizvodi-odabrano">
<br>

<?php 

$pretraga = $_POST["pretraga"]; //hvatanje vrednosti iz URL-a
include("config/connection.php");
$upit = "SELECT b.Naziv, a.Model, a.Cena, a.img, a.href FROM artikal AS a INNER JOIN brend AS b ON a.marka = b.Id
WHERE b.Naziv LIKE '%$pretraga%' OR a.Model LIKE '%$pretraga%' ORDER BY a.Cena ASC";
$rezultat = $db->query($upit);
if(mysqli_num_rows($rezultat) > 0){
while($row = $rezultat->fetch_array()){
    $img = $row["img"];
    $Naziv = $row["Naziv"];
    $Model = $row["Model"];
    $Cena = $row["Cena"];
    $href = $row["href"];
    echo '
    <div class="kartica">
      <div class="slika">
        <img src="'.$img.'" alt="TV">
      </div>
      <div class="naslov-kartice">
        <h3>'.$Naziv.'</h3>
        <h4>'.$Model.'</h4> 
      </div>
      <div class="cena-kartice">
        <h3>'.$Cena.'</h3>
      </div>
      <div class="dugme-kartice">
        <a href="models/korpa.php'.$href.'"><i class="fas fa-shopping-cart"></i> <span>Dodaj u korpu</span></a>
      </div>
      <div id="detaljnije" class="dugme-kartice">
        <a href="detalji.php'.$href.'"><i class="fas fa-search"></i> <span>Detaljnije</span></a>
      </div>
    </div>';
}
}
else{
  echo '<h3 style="color:tomato">Trazeni artikal ne postoji u bazi<h3>';
}
?>

</div>
<script type="text/javascript">
$(window).on('load' , function(){
    $("#pocetna-link").removeClass("active");
});

</script>
<script type="text/javascript" src="assets/js/main.js"></script>

<?php 
include("views/fixed/footer.php");
//pregled pretrage
?>