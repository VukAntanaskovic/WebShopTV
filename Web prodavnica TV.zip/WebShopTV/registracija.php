<?php 
include("views/fixed/header.php");
include("views/fixed/navbar.php");
include("config/connection.php");
if(isset($_POST['btnRegistruj'])){
    $ime = $_POST['ime'];
    $prezime = $_POST['prezime'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $password = md5($password);
    $upit = "INSERT INTO korisnik VALUES (null, '$ime' , '$prezime' , '$email' , '$password')";

    if($db ->query($upit) === TRUE){
        $_SESSION["Uspesno"] = '    <div id="greska" class="sekcija" style="background-color:#087062">
        <h5>Uspesno ste se registrovali</h5>
</div>';
echo $_SESSION["Uspesno"];
    }
    else{
        echo '    <div id="greska" class="sekcija">
        <h5>Greska prilikom kreiranja naloga</h5>
    </div>';
    }


}
//registracija novog korisnika
?>
<h2 class="naslov-login">WEB Prodavnica TV</h2>
<form action="registracija.php" method="POST" class="login-forma">
    <h3>Registrujte se</h3>
<div class="sekcija">
    <label for="input-ime" class="label-mail">Ime</label>
    <input name="ime" autocomplete="off" type="text" id="input-ime" placeholder="Unesite vase ime..." required>
    </div>
    <div class="sekcija">
    <label for="input-prezime" class="label-mail">Prezime</label>
    <input name="prezime" autocomplete="off" type="text" id="input-prezime" placeholder="Unesite vas prezime..." required>
    </div>
    <div class="sekcija">
    <label for="input-email" class="label-mail">Email</label>
    <input name="email" autocomplete="off" type="email" id="input-email" placeholder="Unesite vas email..." required>
    </div>
    <div class="sekcija">
    <label for="input-password" class="label-mail">Password</label>
    <input name="password" autocomplete="off" type="password" id="input-password" placeholder="Unesite vas password..." required>
</div>
<div class="login-dugme">
    <button type="submit" name="btnRegistruj">Registrujte se</button>
</div>
<div class="login-dugme">
    <a href="prijava.php" type="submit">Vratite se na prijavu</a>
</div>
</form>










</body>
</html>

<script>
    $(document).ready(function(){
    $("body").addClass("slika-login");
    $("nav").css("visibility", "hidden");
});
</script>