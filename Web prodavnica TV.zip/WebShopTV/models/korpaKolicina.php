<?php
session_start();
include("../config/connection.php");
//polja 
$sifra = $_GET["sifra"];
$kolicina = $_GET["kolicina"];
$sifraKorpe = $_SESSION["sifraKorpe"];
//--polja
//cena
$upitCena = "SELECT cena FROM artikal WHERE sifra_artikla = '$sifra'";
$rezultatCena = $db->query($upitCena);
while($rowCena = $rezultatCena->fetch_array()){
$cena = $rowCena["cena"];
$cena = $cena*$kolicina;

$upit = "UPDATE stavke_korpe SET kolicina = '$kolicina' , cena = '$cena' WHERE sifra_korpe = '$sifraKorpe' AND sifra_artikla = '$sifra'";
if($db->query($upit) === TRUE){
    header("Location: http://127.0.0.1/WebShopTV/pregledKorpe.php?id=$sifraKorpe");
}
else{
    header("Location: http://127.0.0.1/WebShopTV/pregledKorpe.php?id=$sifraKorpe");
}
}

//azuriranje kolicine i cene tokom pregleda korpe
?>