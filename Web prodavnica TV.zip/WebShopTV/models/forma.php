<?php 
include("../config/connection.php");

$ime = $_POST['Kontakt-ime'];
$email = $_POST['Kontakt-email'];
$komentar = $_POST['Kontakt-komentar'];

$upit = "INSERT INTO forma VALUES (null ,'$ime' , '$email' , '$komentar')";

if($db->query($upit) === TRUE){
    header("Location:../index.php");
}
else{
    header("Location:../index.php");
}

//unos komentara korisnika
?>