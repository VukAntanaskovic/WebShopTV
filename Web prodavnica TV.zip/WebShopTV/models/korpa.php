<?php 
session_start();
include("../config/connection.php");
$sifraKorpe = $_SESSION["sifraKorpe"];
if($sifraKorpe == null){
    $upit = "INSERT INTO korpa VALUES(null)";
    if($db->query($upit) === TRUE){
        //kreiranje korpe
        $uzmiSifruUpit = "SELECT sifra_korpe FROM korpa ORDER BY sifra_korpe DESC LIMIT 1";
        $uzmiSifruRezultat = $db->query($uzmiSifruUpit);
        $uzmiSifruRow = $uzmiSifruRezultat->fetch_assoc();
        $sifraKorpe = $uzmiSifruRow['sifra_korpe'];
        $_SESSION["sifraKorpe"] = $sifraKorpe;
        //--kreiranje korpe

        //pocetni parametri za unos
        $sifraArtikla = $_GET["id"];
        $kolicina = 1;
        $upitCena = "SELECT cena FROM artikal WHERE sifra_artikla = '$sifraArtikla'";
        $cenaRezultat = $db->query($upitCena);
        $cenaRow = $cenaRezultat->fetch_assoc();
        $cena = $cenaRow["cena"];
        //--pocetni parametri za unos

        //unos artikala
        $ulistajUpit = "INSERT INTO stavke_korpe VALUES ('$sifraKorpe' , '$sifraArtikla' , '$kolicina' , '$cena')";
        if($db->query($ulistajUpit) === TRUE){
            $brojArtikala = "SELECT COUNT(*) FROM stavke_korpe WHERE sifra_korpe = '$sifraKorpe'";
            $brojRezultat = $db->query($brojArtikala);
            $brojRow = $brojRezultat->fetch_array();
            $_SESSION["brojKorpa"] = $brojRow[0];
            header("Location: " . $_SERVER["HTTP_REFERER"]);
        }
        //--unos artikala
    }
}
else{
    $uzmiSifruUpit = "SELECT sifra_korpe FROM korpa ORDER BY sifra_korpe DESC LIMIT 1";
        $uzmiSifruRezultat = $db->query($uzmiSifruUpit);
        $uzmiSifruRow = $uzmiSifruRezultat->fetch_assoc();
        $sifraKorpe = $uzmiSifruRow['sifra_korpe'];
        $_SESSION["sifraKorpe"] = $sifraKorpe;

         //pocetni parametri za unos
         $sifraArtikla = $_GET["id"];
         $kolicina = 1;
         $upitCena = "SELECT cena FROM artikal WHERE sifra_artikla = '$sifraArtikla'";
         $cenaRezultat = $db->query($upitCena);
         $cenaRow = $cenaRezultat->fetch_assoc();
         $cena = $cenaRow["cena"];
         //--pocetni parametri za unos
 
         //unos artikala
         $ulistajUpit = "INSERT INTO stavke_korpe VALUES ('$sifraKorpe' , '$sifraArtikla' , '$kolicina' , '$cena')";
         if($db->query($ulistajUpit) === TRUE){
            $brojArtikala = "SELECT COUNT(*) FROM stavke_korpe WHERE sifra_korpe = '$sifraKorpe'";
            $brojRezultat = $db->query($brojArtikala);
            $brojRow = $brojRezultat->fetch_array();
            $_SESSION["brojKorpa"] = $brojRow[0];
            header("Location: " . $_SERVER["HTTP_REFERER"]); // salje na stranu odakle smo zatrazili unos u korpu
        }
}

//kreiranje nove korpe i unos pocetno ili svakog narednog artikla u korpu
?>