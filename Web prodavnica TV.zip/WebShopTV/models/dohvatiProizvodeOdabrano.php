<?php 
include("../config/connection.php");

$upit = "SELECT b.Naziv, a.Model, a.Cena, a.img, a.href FROM odabrano_za_vas AS i INNER JOIN artikal AS a ON i.sifra_artikla = a.sifra_artikla INNER JOIN brend AS b ON a.marka = b.Id";
$rezultat = $db->query($upit);
while($row = $rezultat->fetch_all()){
    echo json_encode($row);
}

//uzimanje odabranih proizvoda iz baze

?>