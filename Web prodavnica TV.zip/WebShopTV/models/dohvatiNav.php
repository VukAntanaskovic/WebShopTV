<?php 
include("../config/connection.php");

$upit = "SELECT Naziv, href FROM brend";
$rezultat = $db->query($upit);
while($row = $rezultat->fetch_all()){
    echo json_encode($row);
}

//hvatanje kategorija iz baze

?>