<?php 
session_start();
include("../config/connection.php");
$sifraKorpe = $_SESSION["sifraKorpe"];
$sifraArtikla = $_GET["id"];

$upit = "DELETE FROM stavke_korpe WHERE sifra_korpe = '$sifraKorpe' AND sifra_artikla = '$sifraArtikla'";
if($db->query($upit) === TRUE){
    $brojArtikala = "SELECT COUNT(*) FROM stavke_korpe WHERE sifra_korpe = '$sifraKorpe'";
            $brojRezultat = $db->query($brojArtikala);
            $brojRow = $brojRezultat->fetch_array();
            $_SESSION["brojKorpa"] = $brojRow[0];
            if($_SESSION["brojKorpa"] > 0){
    header("Location: http://127.0.0.1/WebShopTV/pregledKorpe.php?id=$sifraKorpe");
            }
            else{
                header("Location: ../index.php");
            }
}
else{
    echo "Ne radi";
}

//brisanje artikla iz aktivne korpe

?>