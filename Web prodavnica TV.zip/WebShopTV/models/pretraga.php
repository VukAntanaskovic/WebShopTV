<?php 
include("../config/connection.php");
if(isset($_POST["query"])){
    $txtPretraga = $_POST["query"];
$upit = "SELECT b.Naziv, a.Model, a.Cena, a.img, a.dijagonala, a.rezolucija, a.tjuner, a.href FROM artikal AS a INNER JOIN brend AS b ON a.marka = b.Id
 WHERE b.Naziv LIKE '%$txtPretraga%' OR a.Model LIKE '%$txtPretraga%'";
$rezultat = $db->query($upit);
if($rezultat->num_rows>0){
while($row = $rezultat->fetch_all()){
    echo json_encode($row);
}
}
else{
    echo "Trazeni artikal ne postoji!";
}
}

//pretraga artikala
?>