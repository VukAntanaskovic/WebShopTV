<?php 
include("../config/connection.php");
$upit = "SELECT b.Naziv, a.Model, a.Cena, a.img, a.dijagonala, a.href FROM artikal AS a INNER JOIN brend AS b ON a.marka = b.Id ORDER BY a.Cena DESC";
$rezultat = $db->query($upit);
while($row = $rezultat->fetch_all()){
    echo json_encode($row);
}

//uzimanje svih proizvoda iz baze
?>