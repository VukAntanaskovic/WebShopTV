<?php 
session_start();
include("../config/connection.php");

$ime = $_POST["ime"];
$prezime = $_POST["prezime"];
$adresa = $_POST["adresa"];
$telefon = $_POST["telefon"];
$korpa = $_GET["id"];

$upit = "INSERT INTO narudzbenica VALUES (null , '$ime' , '$prezime' , '$telefon' , '$adresa' , '$korpa')";
if($db->query($upit) === TRUE){
    $uzmiBrojUpit = "SELECT broj FROM narudzbenica ORDER BY broj DESC LIMIT 1";
    $uzmiBrojRezultat = $db->query($uzmiBrojUpit);
    $uzmiBrojRow = $uzmiBrojRezultat->fetch_assoc();
    $broj = $uzmiBrojRow['broj'];
    $_SESSION["sifraKorpe"] = null;
    $_SESSION["brojKorpa"] = 0;
    header("Location: ../narudzbenica.php?broj=".$broj);
}
else{
    header("Location: ../index.php");
}

//kreiranje nove narudzbenice
?>