<?php 
session_start();
include("../../config/connection.php");
if(isset($_POST["btnUnesiteBrend"])){
$naziv = $_POST["brend"];
$href = "?kategorija=".$naziv;
$upit = "INSERT INTO brend VALUES (null , '$naziv' , '$href')";
if($db->query($upit) === TRUE){
    $_SESSION["poruka"] = "Uspesno ste uneli brend";
    header("Location: ../../admin.php");
}
else{
    $_SESSION["poruka"] = "Greska pri unosu brenda";
    header("Location: ../../admin.php");
}
}
elseif(isset($_POST["btnObrisiteBrend"])){
    $naziv1 = $_POST["brend"];
    $upit1 = "DELETE FROM brend WHERE Naziv='$naziv1'";
    if($db->query($upit1) === TRUE){
        $_SESSION["poruka"] = "Uspesno ste obrisali brend";
        header("Location: ../../admin.php");
    }
    else{
        $_SESSION["poruka"] = "Brend se moze obrisati samo ako nema artikla sa tim brendom u bazi";
        header("Location: ../../admin.php");
    }
}

//unos novog brenda u bazu
?>