<?php 
session_start();
include("../../config/connection.php");
if(isset($_POST["btnUnesiteOdabrano"])){
$sifra = $_POST["sifra_artikla"];
$upit = "INSERT INTO odabrano_za_vas VALUES ('$sifra')";
if($db->query($upit) === TRUE){
    $_SESSION["porukaOdabrano"] = "Uspesno ste uneli artikal u odabrano iz ponude";
    header("Location: ../../admin.php");
}
else{
    $_SESSION["porukaOdabrano"] = "Greska pri unosu artikla";
    header("Location: ../../admin.php");
}
}
elseif(isset($_POST["btnObrisiteOdabrano"])){
    $sifra1 = $_POST["sifra_artikla"];
    $upit1 = "DELETE FROM odabrano_za_vas WHERE sifra_artikla='$sifra1'";
    if($db->query($upit1) === TRUE){
        $_SESSION["porukaOdabrano"] = "Uspesno ste obrisali artikal iz odabranih proizvoda";
        header("Location: ../../admin.php");
    }
    else{
        $_SESSION["porukaOdabrano"] = "Artikal se ne moze izbrisati iz odabranih proizvoda";
        header("Location: ../../admin.php");
    }
}

//unos i brisanje artikala iz odabrano za vas
?>

