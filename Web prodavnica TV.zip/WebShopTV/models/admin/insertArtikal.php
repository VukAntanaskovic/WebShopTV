<?php
session_start();
include("../../config/connection.php");
if(isset($_POST["btnUnesiteArtikal"])){
//global
$dozvoljene_ekstenzije = array('jpg' , 'jpeg' , 'png');
//--global
//naslovna slika
$naslovna_slika = $_FILES['NaslovnaImg'];
$ime_naslovne_slike = $_FILES['NaslovnaImg']['name'];
$tmpIme_naslovne_slike = $_FILES['NaslovnaImg']['tmp_name'];
$velicina_naslovne_slike = $_FILES['NaslovnaImg']['size'];
$error_naslovne_slike = $_FILES['NaslovnaImg']['error'];
$tipFajla_naslovne_slike = $_FILES['NaslovnaImg']['type'];
$ekstenzija_naslovne_slike = explode('.' , $ime_naslovne_slike);
$prava_ekstenzija_naslovne_slike = strtolower(end($ekstenzija_naslovne_slike));
//--naslovna slika

//img1
$img1 = $_FILES['img1'];
$ime_img1 = $_FILES['img1']['name'];
$tmpIme_img1 = $_FILES['img1']['tmp_name'];
$velicina_img1 = $_FILES['img1']['size'];
$error_img1 = $_FILES['img1']['error'];
$tipFajla_img1 = $_FILES['img1']['type'];
$ekstenzija_img1 = explode('.' , $ime_naslovne_slike);
$prava_ekstenzija_img1 = strtolower(end($ekstenzija_naslovne_slike));
//--img1

//img2
$img2 = $_FILES['img2'];
$ime_img2 = $_FILES['img2']['name'];
$tmpIme_img2 = $_FILES['img2']['tmp_name'];
$velicina_img2 = $_FILES['img2']['size'];
$error_img2 = $_FILES['img2']['error'];
$tipFajla_img2 = $_FILES['img2']['type'];
$ekstenzija_img2 = explode('.' , $ime_img2);
$prava_ekstenzija_img2 = strtolower(end($ekstenzija_img2));
//--img2

//img3
$img3 = $_FILES['img3'];
$ime_img3 = $_FILES['img3']['name'];
$tmpIme_img3 = $_FILES['img3']['tmp_name'];
$velicina_img3 = $_FILES['img3']['size'];
$error_img3 = $_FILES['img3']['error'];
$tipFajla_img3 = $_FILES['img3']['type'];
$ekstenzija_img3 = explode('.' , $ime_img3);
$prava_ekstenzija_img3 = strtolower(end($ekstenzija_img3));
//--img3

//polja za bazu
$marka = $_POST['marka'];
$model = $_POST['model'];
$cena = $_POST['cena'];
$dijagonala = $_POST['dijagonala'];
$rezolucija = $_POST['rezolucija'];
$smart = $_POST['smart'];
$tjuner = $_POST['tjuner'];
$hdmi = $_POST['hdmi'];
$usb = $_POST['usb'];
//--polja za bazu


if(in_array($prava_ekstenzija_naslovne_slike, $dozvoljene_ekstenzije) && in_array($prava_ekstenzija_img1, $dozvoljene_ekstenzije) && in_array($prava_ekstenzija_img2, $dozvoljene_ekstenzije) && in_array($prava_ekstenzija_img3, $dozvoljene_ekstenzije)){
    if($error_naslovne_slike === 0 && $error_img1 === 0 && $error_img2 === 0 && $error_img3 === 0){
        if($velicina_naslovne_slike < 1000000 && $velicina_img1 < 1000000 && $velicina_img2 < 1000000 && $velicina_img3 < 1000000){
            $novi_fajl_naslovna = uniqid('' , true).".".$prava_ekstenzija_naslovne_slike;
            $novi_fajl_img1 = uniqid('' , true).".".$prava_ekstenzija_img1;
            $novi_fajl_img2 = uniqid('' , true).".".$prava_ekstenzija_img2;
            $novi_fajl_img3 = uniqid('' , true).".".$prava_ekstenzija_img3;
            $putanja = "../../assets/img/".$novi_fajl_naslovna;
            $putanjaImg1 = "../../assets/img/".$novi_fajl_img1;
            $putanjaImg2 = "../../assets/img/".$novi_fajl_img2;
            $putanjaImg3 = "../../assets/img/".$novi_fajl_img3;
            move_uploaded_file($tmpIme_naslovne_slike , $putanja);
            move_uploaded_file($tmpIme_img1 , $putanjaImg1);
            move_uploaded_file($tmpIme_img2 , $putanjaImg2);
            move_uploaded_file($tmpIme_img3 , $putanjaImg3);
            $baznaPutanja_naslovna = "assets/img/" .$novi_fajl_naslovna;
            $baznaPutanja_img1 = "assets/img/" .$novi_fajl_img1;
            $baznaPutanja_img2 = "assets/img/" .$novi_fajl_img2; 
            $baznaPutanja_img3 = "assets/img/" .$novi_fajl_img3;  
            $upit = "INSERT INTO artikal VALUES (null , '$marka' , '$model' , '$cena' , '$dijagonala' , '$rezolucija' , '$smart' , '$tjuner' , '$hdmi' , '$usb' , '$baznaPutanja_naslovna' , '' , '$baznaPutanja_img1' , '$baznaPutanja_img2' , '$baznaPutanja_img3')";
            if($db->query($upit) === TRUE){
                $traziId="SELECT sifra_artikla FROM artikal ORDER BY sifra_artikla DESC LIMIT 1";
                $rezultat = $db->query($traziId);
                $row = $rezultat->fetch_assoc();
                $poslednja_sifra_artikla = $row['sifra_artikla'];
                $azuriranjeUpit = "UPDATE artikal SET href='?id=$poslednja_sifra_artikla' WHERE sifra_artikla='$poslednja_sifra_artikla'";
                if($db->query($azuriranjeUpit) === TRUE){
            $_SESSION["porukaArtikal"] = "Uspesno ste uneli novi artikal";
            header("Location: ../../admin.php");
                }
                else{
                    $_SESSION["porukaArtikal"] = "Greska pri unosu artikla u bazu";
                    header("Location: ../../admin.php");
                }
            }
            else{
                $_SESSION["porukaArtikal"] = "Greska pri unosu artikla u bazu";
                header("Location: ../../admin.php");
            }
        }
        else{
            $_SESSION["porukaArtikal"] = "Slika je prevelika";
            header("Location: ../../admin.php"); 
        }
    }
    else{
        $_SESSION["porukaArtikal"] = "Greska prilikom ucitavanja fajla";
        header("Location: ../../admin.php");
    }
}
else{
    $_SESSION["porukaArtikal"] = "Neispravan tip fajla";
    header("Location: ../../admin.php");
}



}

//upisivanje novog artikla u bazu
?>