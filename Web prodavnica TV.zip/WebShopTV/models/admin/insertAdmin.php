<?php 
session_start();
include("../../config/connection.php");
if(isset($_POST["btnUnesiteAdmina"])){
$sifra = $_POST["sifra_korisnika"];
$upit = "INSERT administrator VALUES ('$sifra')";
if($db->query($upit) === TRUE){
    $_SESSION["porukaAdmin"] = "Uspesno ste uneli administratora";
    header("Location: ../../admin.php");
}
else{
    $_SESSION["poruka"] = "Greska pri unosu administratora";
    header("Location: ../../admin.php");
}
}
elseif(isset($_POST["btnObrisiteAdmina"])){
    $sifra1 = $_POST["sifra_korisnika"];
    $upit1 = "DELETE FROM administrator WHERE id_korisnika='$sifra1'";
    if($db->query($upit1) === TRUE){
        $_SESSION["porukaAdmin"] = "Uspesno ste obrisali admina";
        header("Location: ../../admin.php");
    }
    else{
        $_SESSION["porukaAdmin"] = "Ne mozete obrisati admina";
        header("Location: ../../admin.php");
    }
}
//upisivanje novog administratora u bazu
?>