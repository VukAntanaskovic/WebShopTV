<?php 
session_start();
include("../../config/connection.php");
$sifra = $_POST['sifra_artikla'];
$cena = $_POST['promenaCene'];

$upit = "UPDATE artikal SET cena = '$cena' WHERE sifra_artikla = '$sifra'";
if($db->query($upit) === TRUE){
    $_SESSION["porukaCena"] = "Uspesno ste promenili cenu";
    header("Location: ../../admin.php");
}
else{
    $_SESSION["porukaCena"] = "Greska prilikom promene cene";
    header("Location: ../../admin.php");
}

//promena cene artikla
?>