<?php 
session_start();
include("../../config/connection.php");
if(isset($_POST["btnUnesiteIzdvajamo"])){
$sifra = $_POST["sifra_artikla"];
$upit = "INSERT INTO izdvajamo_iz_ponude VALUES ('$sifra')";
if($db->query($upit) === TRUE){
    $_SESSION["porukaIzdvajamo"] = "Uspesno ste uneli artikal u izdvojene iz ponude";
    header("Location: ../../admin.php");
}
else{
    $_SESSION["porukaIzdvajamo"] = "Greska pri unosu artikla";
    header("Location: ../../admin.php");
}
}
elseif(isset($_POST["btnObrisiteIzdvajamo"])){
    $sifra1 = $_POST["sifra_artikla"];
    $upit1 = "DELETE FROM izdvajamo_iz_ponude WHERE sifra_artikla='$sifra1'";
    if($db->query($upit1) === TRUE){
        $_SESSION["porukaIzdvajamo"] = "Uspesno ste obrisali artikal iz izdvojenih proizvoda";
        header("Location: ../../admin.php");
    }
    else{
        $_SESSION["porukaIzdvajamo"] = "Artikal se ne moze izbrisati iz izdvojenih proizvoda";
        header("Location: ../../admin.php");
    }
}
//unos i brisanje artikala u izdvajamo iz ponude
?>

