<?php 
session_start();
session_destroy();
header("Location: ../index.php");

//prekid session-a i odjava korisnika
?>