-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 26, 2021 at 11:15 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `prodavnica_tv`
--

-- --------------------------------------------------------

--
-- Table structure for table `administrator`
--

CREATE TABLE `administrator` (
  `id_korisnika` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `administrator`
--

INSERT INTO `administrator` (`id_korisnika`) VALUES
(7),
(9);

-- --------------------------------------------------------

--
-- Table structure for table `artikal`
--

CREATE TABLE `artikal` (
  `sifra_artikla` int(10) NOT NULL,
  `marka` int(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  `cena` decimal(30,0) NOT NULL,
  `dijagonala` varchar(100) NOT NULL,
  `rezolucija` varchar(100) NOT NULL,
  `smart` varchar(100) NOT NULL,
  `tjuner` varchar(100) NOT NULL,
  `hdmi` varchar(100) NOT NULL,
  `usb` varchar(100) NOT NULL,
  `img` varchar(255) NOT NULL,
  `href` varchar(255) NOT NULL,
  `img1` varchar(255) NOT NULL,
  `img2` varchar(255) NOT NULL,
  `img3` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `artikal`
--

INSERT INTO `artikal` (`sifra_artikla`, `marka`, `model`, `cena`, `dijagonala`, `rezolucija`, `smart`, `tjuner`, `hdmi`, `usb`, `img`, `href`, `img1`, `img2`, `img3`) VALUES
(1, 1, 'UE32RU7022KXXG', '25990', '32', '1920x1080', 'da', 'dvbt2', '3', '2', 'assets/img/slika.jpg', '?id=1', 'assets/img/img1.jpg', 'assets/img/img2.jpg', 'assets/img/img3.jpg'),
(2, 3, '32DLE192', '9990', '32', '1398x780', 'ne', 'dvbt2', '2', '1', 'assets/img/tv.jpg', '?id=2', 'assets/img/img1.jpg', 'assets/img/img2.jpg', 'assets/img/img3.jpg'),
(3, 4, '32ADS311G', '15650', '32', '1920x1080', 'da', 'dvbt2', '2', '2', 'assets/img/vox.jpg', '?id=3', 'assets/img/img1.jpg', 'assets/img/img2.jpg', 'assets/img/img3.jpg'),
(4, 4, '32DSA311B', '9990', '32', '1920x1080', 'da', 'dvbt2', '2', '2', 'assets/img/311.jpg', '?id=4', 'assets/img/img1.jpg', 'assets/img/img2.jpg', 'assets/img/img3.jpg'),
(5, 2, '32LB521C', '32990', '32', '1920X1080', 'da', 'dvbt2', '2', '2', 'assets/img/lg.jpg', '?id=5', 'assets/img/img1.jpg', 'assets/img/img2.jpg', 'assets/img/img3.jpg'),
(6, 3, '32DLE268', '15990', '32', '1380x720', 'da', 'dvbt2', '2', '1', 'assets/img/268.jpg', '?id=6', 'assets/img/img1.jpg', 'assets/img/img2.jpg', 'assets/img/img3.jpg'),
(7, 3, '43DLE462', '25990', '43', '1920x1080', 'ne', 'dvbt2', '2', '1', 'assets/img/462.jpg', '?id=7', 'assets/img/img1.jpg', 'assets/img/img2.jpg', 'assets/img/img3.jpg'),
(18, 5, 'TX-43HX710E', '69990', '43', '3840x2160', 'da', 'dvbt2/dvbs/dvb', '3', '3', 'assets/img/6030393b03a036.32701410.jpg', '?id=18', 'assets/img/6030393b03a0c0.30475755.jpg', 'assets/img/6030393b03a0d7.11220980.jpg', 'assets/img/6030393b03a0e9.60710117.png'),
(19, 5, 'TX-43HX900E', '75990', '43', '3840x2160', 'da', 'dvbt2/dvbs/dvb', '3', '3', 'assets/img/60303967620db7.32924651.png', '?id=19', 'assets/img/60303967620e58.66236754.png', 'assets/img/60303967620e87.14599000.jpg', 'assets/img/60303967620ea7.36372051.jpg'),
(20, 5, 'TX-50GX810E', '89990', '50', '3840x2160', 'da', 'dvbt2/dvbs/dvb', '3', '3', 'assets/img/603039cf514df3.55731818.png', '?id=20', 'assets/img/603039cf514e93.54219239.png', 'assets/img/603039cf514eb1.69253366.jpg', 'assets/img/603039cf514ee8.40454703.jpg'),
(21, 5, 'TX-55HZ1500E', '105990', '55', '3840x2160', 'da', 'dvbt2/dvbs/dvb', '3', '3', 'assets/img/603039fbbcc400.34924350.png', '?id=21', 'assets/img/603039fbbcc493.25855948.png', 'assets/img/603039fbbcc4d9.62324474.jpg', 'assets/img/603039fbbcc4f1.51955942.jpg'),
(22, 5, 'TX-65GX820E', '159990', '65', '3840x2160', 'da', 'dvbt2/dvbs/dvb', '3', '3', 'assets/img/60303a2f197c45.67735374.png', '?id=22', 'assets/img/60303a2f197ce9.61369333.png', 'assets/img/60303a2f197d06.47950030.jpg', 'assets/img/60303a2f197d36.00779025.jpg'),
(23, 5, 'TX-65GZ2000E', '179990', '65', '3840x2160', 'da', 'dvbt2/dvbs/dvb', '3', '3', 'assets/img/60303a55952512.99096771.png', '?id=23', 'assets/img/60303a559525b9.96428596.png', 'assets/img/60303a559525e8.62391135.jpg', 'assets/img/60303a55952614.81586075.jpg'),
(24, 5, 'TX-65HX940E', '199990', '65', '3840x2160', 'da', 'dvbt2/dvbs/dvb', '3', '3', 'assets/img/60303a8291b8c3.58608066.png', '?id=24', 'assets/img/60303a8291b970.53122821.png', 'assets/img/60303a8291b991.84106439.jpg', 'assets/img/60303a8291b9b1.75657764.jpg'),
(25, 5, 'TX-65HZ980E', '205990', '65', '3840x2160', 'da', 'dvbt2/dvbs/dvb', '3', '3', 'assets/img/60303ad20f7f80.35214230.png', '?id=25', 'assets/img/60303ad20f8028.83146858.png', 'assets/img/60303ad20f8053.66548944.jpg', 'assets/img/60303ad20f8084.70851579.jpg'),
(26, 5, 'TX-65HZ1000E', '255000', '65', '3840x2160', 'da', 'dvbt2/dvbs/dvb', '3', '3', 'assets/img/60303b0231b332.43044478.png', '?id=26', 'assets/img/60303b0231b3e3.11029027.png', 'assets/img/60303b0231b410.04296231.jpg', 'assets/img/60303b0231b449.66489552.jpg'),
(27, 5, 'TX-65HZ1500E', '479990', '65', '3840x2160', 'da', 'dvbt2/dvbs/dvb', '3', '3', 'assets/img/60303b29ba1904.16915397.png', '?id=27', 'assets/img/60303b29ba1993.08676953.png', 'assets/img/60303b29ba19c7.24914355.jpg', 'assets/img/60303b29ba19f9.41372909.jpg'),
(28, 6, '43A7500F', '55990', '43', '3840x2160', 'da', 'dvbt2/dvbs/dvb', '3', '3', 'assets/img/6034e4588c34f9.52200627.png', '?id=28', 'assets/img/6034e4588c3592.82414824.png', 'assets/img/6034e4588c35c9.12575160.jpg', 'assets/img/6034e4588c35f2.36324201.jpg'),
(29, 6, '50A7500F', '69990', '50', '3840x2160', 'da', 'dvbt2/dvbs/dvb', '3', '3', 'assets/img/6034e4884f9835.79903143.png', '?id=29', 'assets/img/6034e4884f98f8.10740405.png', 'assets/img/6034e4884f9955.22278471.jpg', 'assets/img/6034e4884f9989.23782288.jpg'),
(30, 6, '65A7100F', '78990', '65', '3840x2160', 'da', 'dvbt2/dvbs/dvb', '3', '3', 'assets/img/6034e4c67bc5f7.48820634.png', '?id=30', 'assets/img/6034e4c67bc6b0.02926747.png', 'assets/img/6034e4c67bc6f7.92927117.jpg', 'assets/img/6034e4c67bc726.54065742.jpg'),
(31, 6, '65U7QF', '105990', '65', '3840x2160', 'da', 'dvbt2/dvbs/dvb', '3', '3', 'assets/img/6034e4f7604e74.85015354.png', '?id=31', 'assets/img/6034e4f7604f09.05669375.png', 'assets/img/6034e4f7604f47.44629846.jpg', 'assets/img/6034e4f7604f67.13725177.jpg'),
(32, 6, 'H50U7B', '190990', '50', '3840x2160', 'da', 'dvbt2/dvbs/dvb', '3', '3', 'assets/img/6034e545598a42.45513107.png', '?id=32', 'assets/img/6034e545598b11.79387617.png', 'assets/img/6034e545598b44.44881413.jpg', 'assets/img/6034e545598b73.48043980.jpg'),
(33, 8, 'KD-49XH8077', '56990', '50', '3840x2160', 'da', 'dvbt2/dvbs/dvb', '3', '3', 'assets/img/6034e77cd59313.61860859.png', '?id=33', 'assets/img/6034e77cd593f7.30261616.png', 'assets/img/6034e77cd59439.69979072.jpg', 'assets/img/6034e77cd59467.52672676.jpg'),
(34, 8, 'KD-55XH9505', '99990', '55', '3840x2160', 'da', 'dvbt2/dvbs/dvb', '3', '3', 'assets/img/6034e7a74d4956.95754394.png', '?id=34', 'assets/img/6034e7a74d49f4.05127693.png', 'assets/img/6034e7a74d4a24.55770510.jpg', 'assets/img/6034e7a74d4a58.62414049.jpg'),
(35, 8, 'KD-65AG8BAEP', '105990', '65', '3840x2160', 'da', 'dvbt2/dvbs/dvb', '3', '3', 'assets/img/6034e85e9cdb61.68954796.png', '?id=35', 'assets/img/6034e85e9cdc03.33068101.png', 'assets/img/6034e85e9cdc26.70133249.jpg', 'assets/img/6034e85e9cdc54.47178712.jpg'),
(36, 8, 'KD-65XH9005', '150990', '65', '3840x2160', 'da', 'dvbt2/dvbs/dvb', '3', '3', 'assets/img/6034e89c884987.12471115.png', '?id=36', 'assets/img/6034e89c884a31.30685174.png', 'assets/img/6034e89c884a77.08023655.png', 'assets/img/6034e89c884aa1.06805996.jpg'),
(37, 8, 'KDL-43WF665', '49990', '43', '3840x2160', 'da', 'dvbt2/dvbs/dvb', '3', '3', 'assets/img/6034e8c1b6d987.72616489.png', '?id=37', 'assets/img/6034e8c1b6da15.21743379.png', 'assets/img/6034e8c1b6da49.24906577.jpg', 'assets/img/6034e8c1b6da72.10744550.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `brend`
--

CREATE TABLE `brend` (
  `Id` int(30) NOT NULL,
  `Naziv` varchar(100) NOT NULL,
  `href` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `brend`
--

INSERT INTO `brend` (`Id`, `Naziv`, `href`) VALUES
(1, 'Samsung', '?kategorija=Samsung'),
(2, 'LG', '?kategorija=LG'),
(3, 'FOX', '?kategorija=FOX'),
(4, 'VOX', '?kategorija=VOX'),
(5, 'Panasonic', '?kategorija=Panasonic'),
(6, 'Hisense', '?kategorija=Hisense'),
(8, 'Sony', '?kategorija=Sony');

-- --------------------------------------------------------

--
-- Table structure for table `forma`
--

CREATE TABLE `forma` (
  `Id` int(255) NOT NULL,
  `ime` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `poruka` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `forma`
--

INSERT INTO `forma` (`Id`, `ime`, `email`, `poruka`) VALUES
(3, 'Vuk', 'vukantanaskovic99@gmail.com', 'Svidja nam se vasa prodavnica'),
(4, 'Zika', 'zika@zika.com', 'Kupio sam tv u vasoj web prodavnici, stigao mi je i zadovoljan sam.'),
(5, 'Marko', 'marko@gmail.com', 'Prezadovoljan sam vasom prodavnicom.'),
(6, 'Rade', 'rade@gmail.com', 'Stigao mi je polomljen tv'),
(7, 'Mitar', 'Mitar@gmail.com', 'Odlicna prodavnica!');

-- --------------------------------------------------------

--
-- Table structure for table `izdvajamo_iz_ponude`
--

CREATE TABLE `izdvajamo_iz_ponude` (
  `sifra_artikla` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `izdvajamo_iz_ponude`
--

INSERT INTO `izdvajamo_iz_ponude` (`sifra_artikla`) VALUES
(2),
(3),
(4),
(22),
(33);

-- --------------------------------------------------------

--
-- Table structure for table `korisnik`
--

CREATE TABLE `korisnik` (
  `id_korisnika` int(10) NOT NULL,
  `ime` varchar(100) NOT NULL,
  `prezime` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `korisnik`
--

INSERT INTO `korisnik` (`id_korisnika`, `ime`, `prezime`, `email`, `password`) VALUES
(7, 'Vuk', 'Antanaskovic', 'vukantanaskovic99@gmail.com', 'c3df15753d13460242c23473b5e2f973'),
(8, 'Zika', 'Zikic', 'zika@gmail.com', '300aabd4e3e0f7db7c76ae50e370d96f'),
(9, 'Admin', 'br1', 'admin@admin.com', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Table structure for table `korpa`
--

CREATE TABLE `korpa` (
  `sifra_korpe` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `korpa`
--

INSERT INTO `korpa` (`sifra_korpe`) VALUES
(1),
(2),
(3),
(4),
(5),
(6),
(7),
(8),
(9),
(10),
(11),
(12),
(13),
(14),
(15),
(16),
(17),
(18),
(19),
(20),
(21),
(22),
(23),
(24),
(25),
(26),
(27),
(28),
(29);

-- --------------------------------------------------------

--
-- Table structure for table `narudzbenica`
--

CREATE TABLE `narudzbenica` (
  `broj` int(255) NOT NULL,
  `ime` varchar(255) NOT NULL,
  `prezime` varchar(255) NOT NULL,
  `broj_telefona` varchar(255) NOT NULL,
  `adresa` varchar(255) NOT NULL,
  `sifra_korpe` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `narudzbenica`
--

INSERT INTO `narudzbenica` (`broj`, `ime`, `prezime`, `broj_telefona`, `adresa`, `sifra_korpe`) VALUES
(1, 'Marko', 'Petrovic', '062335987', 'Vojvode Stepe', 20),
(12, 'Maja', 'Ramic', '0632256489', 'Ustanicka 134', 21),
(13, 'Maja', 'Ramic', '0632256489', 'Ustanicka 134', 21),
(14, 'Marko', 'Petrovic', '0632256489', 'Ustanicka 134', 21),
(15, 'Maja', 'Markovic', '0632256489', 'Ustanicka 134', 22),
(16, 'Zika', 'Rakic', '0632256489', 'Vojvode Stepe', 23),
(17, 'Mara', 'Petrovic', '0632256489', 'Ustanicka 134', 24),
(18, 'Maja', 'Ramic', '0632256489', 'Ustanicka 134', 24),
(19, 'Marko', 'Petrovic', '0632256489', 'Ustanicka 134', 24),
(20, 'Zika', 'Ramic', '0632256489', 'Ustanicka 134', 25),
(21, 'Maja', 'Ramic', '0632256489', 'Ustanicka 134', 26),
(22, 'Marko', 'Ramic', '0632256489', 'Milana Rakica', 27),
(23, 'Marko', 'Markovic', '0632256489', 'Vojvode Stepe', 28),
(24, 'Mitar', 'Miric', '0632256489', 'Milana Rakica', 29);

-- --------------------------------------------------------

--
-- Table structure for table `odabrano_za_vas`
--

CREATE TABLE `odabrano_za_vas` (
  `sifra_artikla` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `odabrano_za_vas`
--

INSERT INTO `odabrano_za_vas` (`sifra_artikla`) VALUES
(2),
(3),
(4),
(5),
(27);

-- --------------------------------------------------------

--
-- Table structure for table `stavke_korpe`
--

CREATE TABLE `stavke_korpe` (
  `sifra_korpe` int(255) NOT NULL,
  `sifra_artikla` int(255) NOT NULL,
  `kolicina` int(100) NOT NULL,
  `cena` decimal(30,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stavke_korpe`
--

INSERT INTO `stavke_korpe` (`sifra_korpe`, `sifra_artikla`, `kolicina`, `cena`) VALUES
(15, 1, 1, '25990'),
(15, 2, 1, '9990'),
(15, 22, 1, '159990'),
(15, 20, 1, '89990'),
(15, 3, 1, '15650'),
(16, 26, 1, '255000'),
(16, 27, 1, '459990'),
(16, 25, 1, '205990'),
(17, 2, 2, '19980'),
(17, 3, 2, '31300'),
(18, 1, 2, '51980'),
(18, 3, 2, '31300'),
(19, 2, 1, '9990'),
(20, 7, 2, '51980'),
(20, 23, 2, '359980'),
(21, 2, 1, '9990'),
(22, 4, 1, '9990'),
(23, 2, 1, '9990'),
(23, 3, 1, '15650'),
(24, 2, 1, '9990'),
(24, 3, 1, '15650'),
(24, 22, 1, '159990'),
(25, 4, 1, '9990'),
(25, 22, 1, '159990'),
(26, 1, 2, '51980'),
(27, 25, 1, '205990'),
(27, 24, 2, '399980'),
(28, 1, 1, '25990'),
(28, 26, 1, '255000'),
(29, 20, 2, '179980');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `administrator`
--
ALTER TABLE `administrator`
  ADD KEY `_admin` (`id_korisnika`);

--
-- Indexes for table `artikal`
--
ALTER TABLE `artikal`
  ADD PRIMARY KEY (`sifra_artikla`),
  ADD KEY `marka` (`marka`);

--
-- Indexes for table `brend`
--
ALTER TABLE `brend`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `forma`
--
ALTER TABLE `forma`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `izdvajamo_iz_ponude`
--
ALTER TABLE `izdvajamo_iz_ponude`
  ADD KEY `sifra_artikla` (`sifra_artikla`);

--
-- Indexes for table `korisnik`
--
ALTER TABLE `korisnik`
  ADD PRIMARY KEY (`id_korisnika`);

--
-- Indexes for table `korpa`
--
ALTER TABLE `korpa`
  ADD PRIMARY KEY (`sifra_korpe`);

--
-- Indexes for table `narudzbenica`
--
ALTER TABLE `narudzbenica`
  ADD PRIMARY KEY (`broj`),
  ADD KEY `_sifrakorpe` (`sifra_korpe`);

--
-- Indexes for table `odabrano_za_vas`
--
ALTER TABLE `odabrano_za_vas`
  ADD KEY `sifra_artikla` (`sifra_artikla`);

--
-- Indexes for table `stavke_korpe`
--
ALTER TABLE `stavke_korpe`
  ADD KEY `_korpa` (`sifra_korpe`),
  ADD KEY `_artikal` (`sifra_artikla`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `artikal`
--
ALTER TABLE `artikal`
  MODIFY `sifra_artikla` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `brend`
--
ALTER TABLE `brend`
  MODIFY `Id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `forma`
--
ALTER TABLE `forma`
  MODIFY `Id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `korisnik`
--
ALTER TABLE `korisnik`
  MODIFY `id_korisnika` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `korpa`
--
ALTER TABLE `korpa`
  MODIFY `sifra_korpe` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `narudzbenica`
--
ALTER TABLE `narudzbenica`
  MODIFY `broj` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `administrator`
--
ALTER TABLE `administrator`
  ADD CONSTRAINT `_admin` FOREIGN KEY (`id_korisnika`) REFERENCES `korisnik` (`id_korisnika`);

--
-- Constraints for table `artikal`
--
ALTER TABLE `artikal`
  ADD CONSTRAINT `artikal_ibfk_1` FOREIGN KEY (`marka`) REFERENCES `brend` (`Id`);

--
-- Constraints for table `izdvajamo_iz_ponude`
--
ALTER TABLE `izdvajamo_iz_ponude`
  ADD CONSTRAINT `izdvajamo_iz_ponude_ibfk_1` FOREIGN KEY (`sifra_artikla`) REFERENCES `artikal` (`sifra_artikla`);

--
-- Constraints for table `narudzbenica`
--
ALTER TABLE `narudzbenica`
  ADD CONSTRAINT `_sifrakorpe` FOREIGN KEY (`sifra_korpe`) REFERENCES `korpa` (`sifra_korpe`);

--
-- Constraints for table `odabrano_za_vas`
--
ALTER TABLE `odabrano_za_vas`
  ADD CONSTRAINT `odabrano_za_vas_ibfk_1` FOREIGN KEY (`sifra_artikla`) REFERENCES `artikal` (`sifra_artikla`);

--
-- Constraints for table `stavke_korpe`
--
ALTER TABLE `stavke_korpe`
  ADD CONSTRAINT `_artikal` FOREIGN KEY (`sifra_artikla`) REFERENCES `artikal` (`sifra_artikla`),
  ADD CONSTRAINT `_korpa` FOREIGN KEY (`sifra_korpe`) REFERENCES `korpa` (`sifra_korpe`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
