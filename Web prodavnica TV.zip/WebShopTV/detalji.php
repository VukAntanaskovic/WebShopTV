<?php 
include("config/connection.php");
include("views/fixed/header.php");
include("views/fixed/navbar.php");
?>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-6">
            <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
                <ol class="carousel-indicators">
                  <li id="line" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active"></li>
                  <li id="line" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1"></li>
                  <li id="line" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2"></li>
                </ol>
                <div class="carousel-inner">
<?php 
$sifra_artikla = $_GET["id"];
$upit = "SELECT model, img1, img2, img3 FROM artikal WHERE sifra_artikla = '$sifra_artikla'";
$rezultat = $db->query($upit);
while($row = $rezultat -> fetch_array()){
    $slika1 = $row["img1"];
    $slika2 = $row["img2"];
    $slika3 = $row["img3"];
    $model = $row["model"];

    if($slika1 != null){
        echo ' <div class="carousel-item active">
        <div class="slika-slajdera">
      <img src="'.$slika1.'" class="d-block w-100" alt="'.$model.'">
  </div>
  </div>';
    }

    if($slika2 != null){
        echo '<div class="carousel-item">
        <div class="slika-slajdera">
            <img src="'.$slika2.'" class="d-block w-100" alt="'.$model.'">
        </div>
      </div>';
    }

    if($slika3 != null){
        echo '<div class="carousel-item">
        <div class="slika-slajdera">
            <img src="'.$slika3.'" class="d-block w-100" alt="'.$model.'">
        </div>
      </div>';
    }

}


?>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-bs-slide="prev">
                  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                  <span class="visually-hidden">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-bs-slide="next">
                  <span class="carousel-control-next-icon" aria-hidden="true"></span>
                  <span class="visually-hidden">Next</span>
                </a>
              </div>
        </div>

<div id="kolona" class="col-lg-6">

<?php 
$sifra_artikla = $_GET["id"];
$upit2 = "SELECT * FROM artikal AS a INNER JOIN brend AS b ON a.marka = b.Id WHERE a.sifra_artikla = '$sifra_artikla'";
$rezultat2 = $db->query($upit2);
while($row2 = $rezultat2->fetch_array()){
  $marka = $row2["Naziv"];//iz tabele brend
  $model = $row2["model"];
  $cena = $row2["cena"];
  $dijagonala = $row2["dijagonala"];
  $rezolucija = $row2["rezolucija"];
  $smart = $row2["smart"];
  $tjuner = $row2["tjuner"];
  $hdmi = $row2["hdmi"];
  $usb = $row2["usb"];
echo '<br><br><h3>'.$marka.' '.$model.'</h3>
<div class="detalji-proizvoda">
    <h4>Proizvodjac: '.$marka.'</h4>
    <h4>Model: '.$model.'</h4>
</div>
<table class="tabela-specifikacija">
<tr>
  <td class="header-tabele">Proizvodjac</td>
  <td class="content-tabele">'.$marka.'</td>
</tr>
<tr>
  <td class="header-tabele">Model</td>
  <td class="content-tabele">'.$model.'</td>
</tr>
<tr>
  <td class="header-tabele">Rezolucija</td>
  <td class="content-tabele">'.$rezolucija.'</td>
</tr>
<tr>
  <td class="header-tabele">Smart</td>
  <td class="content-tabele">'.$smart.'</td>
</tr>
<tr>
  <td class="header-tabele">Tjuner</td>
  <td class="content-tabele">'.$tjuner.'</td>
</tr>
<tr>
  <td class="header-tabele">Dijagonala</td>
  <td class="content-tabele">'.$dijagonala.' `</td>
</tr>
<tr>
  <td class="header-tabele">HDMI</td>
  <td class="content-tabele">'.$hdmi.'</td>
</tr>
<tr>
  <td class="header-tabele">USB</td>
  <td class="content-tabele">'.$usb.'</td>
</tr>
</table>
<div class="cena-detalji">
<h4 class="cena-proizvoda">'.$cena.' rsd</h4>
<h5>+ besplatna dostava</h5>
<div class="dugme-kartice">
<a href="models/korpa.php?id='.$sifra_artikla.'"><i class="fas fa-shopping-cart"></i> <span>Dodaj u korpu</span></a>
</div>
</div>
</div>';





}


?>


</div>
</div>

</div>
<script type="text/javascript">
$(window).on('load' , function(){
    $("#pocetna-link").removeClass("active");
});

</script>
<script type="text/javascript" src="assets/js/main.js"></script>

<?php 
include("views/fixed/footer.php");
//uzimanje artikla i ispis svih detalja preko prolsedjenog url parametra 
?>