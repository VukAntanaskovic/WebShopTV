<div class="sortiranje">
<form method="POST" action="models/dohvatiSveProizvode.php">
<label for="sort">Sortirajte prema:</label>
<select onchange="dohvatiSveProizvode()" name="sortiranje" id="combo-sort" placeholder="Sortirajte" class="s-sort">
<option value="CenaOpadajuce">Cena opadajuce</option>
<option value="CenaRastuce">Cena rastuce</option>
<option value="Marka">Marka</option>
</select>
</form>
</div>
<div class="main">
<div class="col-lg-10">
<h2 class="naslov">Proizvodi</h2>
<div class="iz-ponuda" id="svi-proizvodi">
<br>

</div>
</div>
<div class="col-lg-2 sort-check" id="sort-check">
<h5 class="naslov-sort">Brend</h5>
<ul class="sort-lista" id="lista-proizvodjaca">
</ul>    
<h5 class="naslov-sort">Dijagonala</h5>

<ul class="sort-lista">
    <li onclick="UzmiVrednostDijagonale(this);dohvatiSveProizvode()" value="32">> 32</li>
    <li onclick="UzmiVrednostDijagonale(this);dohvatiSveProizvode()" value="43">> 43</li>
    <li onclick="UzmiVrednostDijagonale(this);dohvatiSveProizvode()" value="50">> 50</li>
    <li onclick="UzmiVrednostDijagonale(this);dohvatiSveProizvode()" value="55">> 55</li>
    <li onclick="UzmiVrednostDijagonale(this);dohvatiSveProizvode()" value="65">> 65</li>
    

</ul>


</select>

</div>
</div>

