<div class="container-fluid" id="dijagonala-c">
<br><h3 class="naslov-dijagonale">Popularne dijagonale</h3>
<div class="row" id="row-dijagonale">
<div class="col-lg-3">
<a class="dijagonale-a" href="pregled_dijagonala.php?dijagonala=32">
32`
</a>
</div>
<div class="col-lg-3">
<a class="dijagonale-a" href="pregled_dijagonala.php?dijagonala=43">
43`
</a>
</div>
<div class="col-lg-3">
<a class="dijagonale-a" href="pregled_dijagonala.php?dijagonala=50">
50`
</a>
</div>
<div class="col-lg-3">
<a class="dijagonale-a" href="pregled_dijagonala.php?dijagonala=55">
55`
</a>
</div>
</div>
</div>