<footer>
    <div class="container-fluid">
        <div class="row">
          <div class="col-lg-6">
            <form action="models/forma.php" method="POST">
              <h3>Kontaktirajte nas</h3>
              <label for="Ime">Ime:*</label>
              <input type="text" name="Kontakt-ime" placeholder="Unesite vase ime" id="Ime" required>
              <label for="Email">Email:</label>
              <input type="text" name="Kontakt-email" placeholder="Unesite vasu email adresu" id="Email">
              <label for="Komentar">Komentar:*</label>
              <textarea name="Kontakt-komentar" placeholder="Unesite vas komentar" id="Komentar" required></textarea>              
              <input type="submit" value="Posaljite">
            </form>
          </div>
          <div class="col-lg-6">
            <h2>WEB Prodavnica TV</h2>
            <div class="fot-nav">
              <h3><i class="fas fa-compass"></i>  Navigacija</h3>
                <a href="index.php">Pocetna</a><br>
                <a href="proizvodi.php">Proizvodi</a><br>
              </div>
              <div class="slika-fot">
              <img src="assets/img/trust.png" alt="trust">
              <div class="fot-nav">
                <h3><i class="fas fa-people-arrows"></i>  Drustvene mreze</h3>
                  <a href="#"><i class="fab fa-facebook"></i></a>
                  <a href="#"><i class="fab fa-instagram"></i></a>
                  <a href="#"><i class="fab fa-twitter-square"></i></a>
                  <a href="#"><i class="fab fa-linkedin"></i></a>
                </div>
            </div>
          </div>
        </div>
    </div>
  </footer>
  <div class="kreator">
    <h4>Vuk Antanaskovic 23.02.2020.  Beograd, ITS</h4>
  </div>




  </body>
</html>