<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
<div class="container-fluid">
<a class="navbar-brand" href="index.php">WEB Prodavnica TV</a>
<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarSupportedContent">
<ul class="navbar-nav me-auto mb-2 mb-lg-0">
<li class="nav-item">
<a class="nav-link active" aria-current="page" href="index.php" id="pocetna-link">Pocetna</a>
</li>
<li class="nav-item">
<a class="nav-link" href="proizvodi.php" id="proizvodi-link">Proizvodi</a>
</li>
<li class="nav-item dropdown">
<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false" id="kategorije-link">
Kategorije proizvoda
</a>
<ul id="padajuci-meni"  class="dropdown-menu" aria-labelledby="navbarDropdown">

</ul>
</li>
<li class="nav-item">
<?php 
session_start();
if(isset($_SESSION["korisnik"])){ 
    echo '<a class="nav-link" href="models/odjava.php"><i class="fas fa-user"></i> Odjavite se</a>';

}
else{
    echo '<a class="nav-link" href="prijava.php"><i class="fas fa-user"></i> Prijavite se</a>';
}

//automatsko biranje izmedju prijave i odjave
?>
</li>
<li class="nav-item">
<?php  
if(isset($_SESSION["brojKorpa"])){
echo '<a id="korpa" class="nav-link" href="pregledKorpe.php?id='.$_SESSION["sifraKorpe"].'"><i class="fas fa-shopping-cart"></i> Korpa <span>('.$_SESSION["brojKorpa"].')</span></a>';
}
//korpa i broj artikala u korpi
?>
</li>
<li class="nav-item">
<?php 
if(isset($_SESSION["korisnik"])){ 
    echo '<a style="color:tomato" class="nav-link" href="admin.php">'.$_SESSION["korisnik"].'</a>';
}
else{
    echo '';
}
//logovanje korisnika
?>
</li>
</ul>
<form class="d-flex" method="POST" action="pregledPretrage.php">
<input autocomplete="off" id="txtPretraga" class="pretraga me-2" type="search" placeholder="Pretraga" aria-label="Search" name="pretraga">
<button id="dugme-pretraga" class="btn" type="submit"><i class="fas fa-search" name="btnPretraga"></i></button>
</form>
<div id="pretraga" class="rezultati-Pretrage">

</div>



</div>
</div>
</nav>
