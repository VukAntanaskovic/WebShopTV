<?php
session_start(); 
include("views/fixed/header.php");
include("views/fixed/navbar.php");
include("config/connection.php");
if(isset($_POST['btnLogin'])){
    $email = $_POST['email'];
    $password = $_POST['password'];
    $password = md5($password);
    $upit = "SELECT * FROM korisnik WHERE email = '$email' AND password = '$password'";
    $rezultat = $db->query($upit);
    $row = $rezultat -> fetch_array();//login
    if($rezultat->num_rows > 0){
        $sifra = $row["id_korisnika"];
        $upit2 = "SELECT * FROM administrator WHERE id_korisnika = '$sifra'";
        $rezultat2 = $db->query($upit2);
        if($rezultat2->num_rows == 0){
        $_SESSION["korisnik"] = $row["ime"] ." ".$row["prezime"];
        header("Location: index.php");
        }
        elseif($rezultat2->num_rows > 0){
            $_SESSION["korisnik"] = "Admin: " .$row["ime"] ." ".$row["prezime"];
            $_SESSION["id_korisnika"] = $sifra;
        header("Location: admin.php");
        }
    
    }
    else{
        $_SESSION["greska"] = '    <div id="greska" class="sekcija">
        <h5>Trazeni korisnik ne postoji, proverite vas unos.</h5>
</div>';
echo $_SESSION["greska"];
    }
}

//prijava korisnika
?>
<h2 class="naslov-login">WEB Prodavnica TV</h2>
<form method="POST" class="login-forma">
    <h3>Ulogujte se</h3>
    <div class="sekcija">
    <label for="input-email" class="label-mail">Email</label>
    <input name="email" autocomplete="off" type="email" id="input-email" placeholder="Unesite vas email..." required>
    </div>
    <div class="sekcija">
    <label for="input-password" class="label-mail">Password</label>
    <input name="password" autocomplete="off" type="password" id="input-password" placeholder="Unesite vas password..." required>
</div>
<div class="login-dugme">
    <button type="submit" name="btnLogin">Ulogujte se</button>
</div>
<div class="login-dugme">
    <a href="registracija.php" type="submit">Registrujte se</a>
</div>
</form>










</body>
</html>

<script>
    $(document).ready(function(){
    $("body").addClass("slika-login");
    $("nav").css("visibility", "hidden");
});
</script>