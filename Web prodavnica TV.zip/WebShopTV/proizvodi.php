<?php 
include("views/fixed/header.php");
include("views/fixed/navbar.php");
include("views/svi_proizvodi.php");
include("views/fixed/footer.php");


?>

<script type="text/javascript" src="assets/js/proizvodi.js"></script>
<script type="text/javascript" src="assets/js/main.js"></script>

