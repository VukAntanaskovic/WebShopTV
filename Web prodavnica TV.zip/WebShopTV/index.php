<?php 
include("views/fixed/header.php");
include("views/fixed/navbar.php");
include("views/slider.php");
include("views/ponuda_proizvodi.php");
include("views/dijagonale.php");
include("views/odabrani_prozivodi.php");
include("views/fixed/footer.php");

?>

<script type="text/javascript" src="assets/js/home.js"></script>
<script type="text/javascript" src="assets/js/main.js"></script>

