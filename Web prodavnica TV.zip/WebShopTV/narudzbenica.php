<?php 
include("views/fixed/header.php");
include("views/fixed/navbar.php");
include("config/connection.php");
$brojNarudzbenice = $_GET["broj"];
$upitNar = "SELECT * FROM narudzbenica WHERE broj = '$brojNarudzbenice'";
$rezultatNar = $db->query($upitNar);
$sifraKorpe= 0;
while($rowNar=$rezultatNar->fetch_array()){
    $ime = $rowNar["ime"];
    $prezime = $rowNar["prezime"];
    $telefon = $rowNar["broj_telefona"];
    $adresa = $rowNar["adresa"];
    $sifraKorpe= $rowNar["sifra_korpe"];

    echo '<div class="container-fluid">
    <div class="row">
        <div class="col-md-6">
            <h3>Narudzbenica broj: '.$brojNarudzbenice.'</h3>
        </div>
        <div class="col-md-6">
            <p>Kupac:<br>Naziv: '.$ime.' '.$prezime.' <br>Adresa: '.$adresa.'<br>Telefon: '.$telefon.'</p>
        </div>
    </div>';

    $upitPrikaz = "SELECT * FROM stavke_korpe AS s INNER JOIN artikal AS a ON s.sifra_artikla = a.sifra_artikla WHERE sifra_korpe='$sifraKorpe'";
    $rezultatPrikaz = $db->query($upitPrikaz);
    $ukupno = 0;
    if($rezultatPrikaz->num_rows > 0){
        echo '<div class="row" id="stampa"><div class="col-md-10"><table class="table table-striped">
        <thead>
          <tr>
          <th scope="col">Slika</th>
            <th scope="col">Naziv artikla</th>
            <th scope="col">Kolicina</th>
            <th scope="col">Cena</th>
          </tr>
        </thead>
        <tbody>';
        while($rowPrikaz=$rezultatPrikaz->fetch_array()){
          $cena = $rowPrikaz["cena"]*$rowPrikaz["kolicina"];
          $ukupno+=$cena;
            echo '<tr><td><img class="korpa-slika" src="'.$rowPrikaz["img"].'"</td><td>'.$rowPrikaz["model"].'</td><td>'.$rowPrikaz["kolicina"].'<td>'.$cena.'</td></tr>';
        }
        }
        else{
          echo '<h3 style="color:tomato">Korpa je prazna</h3>';
        }
}
//pregled narudzbenice
?>
 </tbody>
  </table>
  <h3 align="right">Ukupno: <?php echo $ukupno; ?> rsd</h3>
  </div>
  </div>

</div>

<script>
    $(window).on('load' , function(){
        window.print();
        var korpa = document.getElementById("korpa");
        $(korpa).css("display" , "none");
    });
</script>

