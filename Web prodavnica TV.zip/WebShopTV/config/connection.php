<?php 

$db = mysqli_connect("localhost" , "root" , "" , "prodavnica_tv");

if(!$db){
    die("Greska pri konekciji sa serverom" + $db_error);
}
//konekcija sa bazom
?>

