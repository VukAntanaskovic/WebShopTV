<?php 
include("views/fixed/header.php");
include("views/fixed/navbar.php");
?>

<h2 class="naslov-korpa">Korpa</h2><br>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-6" id="stavke-pregled-korpe">
        <table class="table table-striped">
  <thead>
    <tr>
    <th scope="col">Slika</th>
      <th scope="col">Naziv artikla</th>
      <th scope="col">Kolicina</th>
      <th scope="col">Cena</th>
      <th scope="col"></th>
    </tr>
  </thead>
  <tbody>
<?php
include("config/connection.php");
$sifraKorpe = $_GET["id"];
$upitPrikaz = "SELECT * FROM stavke_korpe AS s INNER JOIN artikal AS a ON s.sifra_artikla = a.sifra_artikla WHERE sifra_korpe='$sifraKorpe'";
$rezultatPrikaz = $db->query($upitPrikaz);
$sif= 0;
$ukupno = 0;
if($rezultatPrikaz->num_rows > 0){
while($rowPrikaz=$rezultatPrikaz->fetch_array()){
  $cena = $rowPrikaz["cena"]*$rowPrikaz["kolicina"];
  $ukupno+=$cena;
  $_SESSION["ukupno"] = $ukupno;
    echo '<tr><td><img class="korpa-slika" src="'.$rowPrikaz["img"].'"</td><td>'.$rowPrikaz["model"].'</td><td><input onchange="potvrdi('.$rowPrikaz["sifra_artikla"].', this)" id="kol" type="number" min="1" name="kolicina" class="form-control"value ="'.$rowPrikaz["kolicina"].'"/></td><td>'.$cena.'</td><td><a class="delete-korpa" href="models/izbrisiIzKorpe.php'.$rowPrikaz["href"].'">X</a></td></tr>';
    $sif = $rowPrikaz["sifra_artikla"];
}
}
else{
  echo '<h3 style="color:tomato">Korpa je prazna</h3>';
}


?>
  <tbody>
  </table>

</div>
<div class="col-md-6">
<form action="<?php echo "models/kreirajNarudzbu.php?id=$sifraKorpe"; ?>" method="POST" class="isporuka">
  <div class="row">
  <div class="col-md-6" id="isporuka-kolona">
  <label for="ime">*Ime</label><br>
  <input type="text" name="ime" id="ime" required>
  </div>
  <div class="col-md-6" id="isporuka-kolona">
  <label for="prezime">*Prezime</label><br>
  <input type="text" name="prezime" id="prezime" required>
  </div>
  </div>
  <div class="row">
  <div class="col-md-6" id="isporuka-kolona">
  <label for="adresa">*Adresa</label><br>
  <input type="text" name="adresa" id="adresa" required>
  </div>
  <div class="col-md-6" id="isporuka-kolona">
  <label for="telefon">*Broj telefona</label><br>
  <input type="text" name="telefon" id="telefon" required>
  </div>
  </div>
  <div class="dugme-nar">
  <button type="submit" class="btn btn-success">Potvrdite porudzbinu</button>
  </div>
</form>
</div>
</div>
<div class="row">
<div class="col-md-6" id="cena-korpe">
<h3>Ukupno: <b><?php echo $ukupno; ?></b></h3>
</div>
<div class="col-md-6" id="cena-korpe">
</div>
</div>
</div>
<script>
function potvrdi(sifra, input){
     var kolicina =  $(input).val();
     if(kolicina != ""){
location.href = "models/korpaKolicina.php?sifra="+sifra+"&kolicina="+kolicina;
}  
}
</script>
<script type="text/javascript">
$(window).on('load' , function(){
    $("#pocetna-link").removeClass("active");
    $("#korpa").addClass("active");
});

</script>
<script type="text/javascript" src="assets/js/main.js"></script>
<?php 
include("views/fixed/footer.php");
//pregled artikala iz korpe
?>